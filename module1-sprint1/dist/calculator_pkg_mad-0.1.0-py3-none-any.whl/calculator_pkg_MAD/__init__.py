"""
A simple calculator.
see README.md or documentation for more details
"""

__version__ = "0.1.0"
